"""
File: examplefor.py
------------------
Print the first 100 even numbers
"""

def main():
    for i in range(12):
        print(i)

# This provided line is required at the end of a Python file
# to call the main() function.
if __name__ == '__main__':
    main()