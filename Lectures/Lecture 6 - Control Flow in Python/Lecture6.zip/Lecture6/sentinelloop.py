"""
File: sentinelloop.py
------------------
Simulate rolling two dice, and prints results of each
roll as well as the total.
"""

def main():
    total = 0
    print(total)

# This provided line is required at the end of a Python file
# to call the main() function.
if __name__ == '__main__':
    main()