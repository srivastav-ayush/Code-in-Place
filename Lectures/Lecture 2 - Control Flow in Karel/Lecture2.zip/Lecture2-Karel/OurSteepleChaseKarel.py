from karel.stanfordkarel import *

"""
File: OurSteepleChaseKarel.py
--------------------------------
Karel runs a steeple chase the is 9 avenues long.
Hurdles are of arbitrary height and placement.
"""


def main():
    pass


# There is no need to edit code beyond this point

if __name__ == "__main__":
    run_karel_program()
