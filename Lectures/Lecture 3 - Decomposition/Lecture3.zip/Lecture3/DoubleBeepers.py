from karel.stanfordkarel import *


def main():
    move()
    # TODO: you fill this in

# still a classic.
def turn_around():
    turn_left()
    turn_left()










if __name__ == "__main__":
    run_karel_program()